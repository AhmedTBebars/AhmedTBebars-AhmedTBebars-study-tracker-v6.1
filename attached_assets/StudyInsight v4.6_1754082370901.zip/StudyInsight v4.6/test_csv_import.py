#!/usr/bin/env python3
"""
CSV Import Test Script for Study Tracker
Tests the CSV import functionality without GUI
"""

import sys
import os
from pathlib import Path

# Add the app directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))

from core.database import DatabaseManager
from core.models import Task, DifficultyLevel
import csv
from datetime import datetime

def test_csv_import():
    """Test CSV import functionality"""
    print("🧪 Testing CSV Import Functionality")
    print("=" * 50)
    
    # Initialize database
    db_manager = DatabaseManager()
    
    # Get initial task count using date range (get all existing tasks)
    from datetime import datetime, timedelta
    start_date = "2020-01-01"  # Far back date to get all tasks
    end_date = (datetime.now() + timedelta(days=365)).strftime("%Y-%m-%d")  # Future date
    all_tasks = db_manager.get_tasks_date_range(start_date, end_date)
    initial_count = len(all_tasks)
    print(f"📊 Initial task count: {initial_count}")
    
    # Process sample CSV
    csv_file = "sample_tasks.csv"
    if not os.path.exists(csv_file):
        print(f"❌ Error: {csv_file} not found!")
        return
    
    imported_count = process_csv_import(db_manager, csv_file)
    
    # Get final task count
    all_tasks_after = db_manager.get_tasks_date_range(start_date, end_date)
    final_count = len(all_tasks_after)
    
    print(f"📊 Final task count: {final_count}")
    print(f"✅ Tasks imported: {imported_count}")
    print(f"📈 Total new tasks added: {final_count - initial_count}")
    
    # Show imported tasks
    print("\n📋 Newly Imported Tasks:")
    print("-" * 30)
    for task in all_tasks_after[-imported_count:] if imported_count > 0 else []:
        status = "✅" if task.is_done else "📝"
        print(f"{status} {task.title}")
        print(f"   📅 {task.date} | 🏷️ {task.topic} | 📊 {task.progress}%")
    
    print("\n🎉 CSV Import Test Completed!")

def process_csv_import(db_manager: DatabaseManager, file_path: str) -> int:
    """Process CSV file and import tasks (console version)"""
    imported_count = 0
    
    print(f"📂 Processing: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as csvfile:
        # Detect CSV dialect
        sample = csvfile.read(1024)
        csvfile.seek(0)
        dialect = csv.Sniffer().sniff(sample)
        
        reader = csv.DictReader(csvfile, dialect=dialect)
        
        # Validate required columns
        required_columns = ['Date', 'Title', 'Topic', 'Is_Done']
        if not all(col in reader.fieldnames for col in required_columns):
            raise ValueError(f"CSV must contain columns: {', '.join(required_columns)}")
        
        print(f"✅ CSV columns validated: {reader.fieldnames}")
        
        for row_num, row in enumerate(reader, start=2):  # Start at 2 for header
            try:
                # Extract and validate data
                date = row['Date'].strip()
                title = row['Title'].strip()
                topic = row['Topic'].strip()
                is_done_str = row['Is_Done'].strip()
                
                # Validate required fields
                if not date or not title:
                    print(f"⚠️  Skipping row {row_num} - missing date or title")
                    continue
                
                # Validate date format
                try:
                    datetime.strptime(date, "%Y-%m-%d")
                except ValueError:
                    print(f"⚠️  Skipping row {row_num} - invalid date format '{date}'. Use YYYY-MM-DD")
                    continue
                
                # Convert is_done to boolean/integer
                is_done = 1 if is_done_str.lower() in ['1', 'true', 'yes', 'completed'] else 0
                
                # Set default topic if empty
                if not topic:
                    topic = 'General'
                
                # Check for duplicates (same date + title)
                existing_tasks = db_manager.get_tasks_by_date(date)
                if any(task.title.lower() == title.lower() for task in existing_tasks):
                    print(f"⚠️  Skipping duplicate: '{title}' on {date}")
                    continue
                
                # Create task object
                task = Task(
                    title=title,
                    topic=topic,
                    date=date,
                    difficulty=DifficultyLevel.MEDIUM,  # Default difficulty
                    is_done=bool(is_done),
                    progress=100 if is_done else 0,  # Set progress based on completion
                    order_index=0  # Will be set automatically by database
                )
                
                # Add task to database
                db_manager.add_task(task)
                imported_count += 1
                status = "✅" if is_done else "📝"
                print(f"✅ Imported: {status} '{title}' ({topic}) on {date}")
                
            except Exception as e:
                print(f"❌ Error processing row {row_num}: {e}")
                continue
    
    return imported_count

if __name__ == "__main__":
    test_csv_import()