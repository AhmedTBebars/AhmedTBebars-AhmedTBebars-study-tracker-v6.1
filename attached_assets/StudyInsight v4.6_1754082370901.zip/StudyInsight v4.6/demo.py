#!/usr/bin/env python3
"""
Study Tracker Demo - Console Interface
Demonstrates the core functionality without GUI requirements
"""

import sys
import os
from datetime import datetime, timedelta
from pathlib import Path

# Add the app directory to the Python path
app_dir = Path(__file__).parent
sys.path.insert(0, str(app_dir))

from app.core.database import DatabaseManager
from app.core.models import Task, DifficultyLevel
from app.features.notifications import NotificationManager
import config

class StudyTrackerDemo:
    """Console demo of Study Tracker functionality"""
    
    def __init__(self):
        # Ensure directories exist
        config.ensure_directories()
        
        # Initialize components
        self.db_manager = DatabaseManager()
        self.notification_manager = NotificationManager()
        self.current_date = datetime.now().strftime("%Y-%m-%d")
        
        print("🎯 Study Tracker Demo - Console Interface")
        print("=" * 50)
    
    def show_menu(self):
        """Display main menu"""
        print(f"\n📅 Current Date: {self.current_date}")
        print("\n📋 Available Actions:")
        print("1. 📝 Add Task")
        print("2. 👁️  View Today's Tasks")
        print("3. ⚠️  View Related Overdue Tasks")
        print("4. 📊 Log Progress")
        print("5. 📈 View Reports")
        print("6. 🔄 Change Date")
        print("7. 💾 Create Backup")
        print("8. 🔔 Test Notification")
        print("9. ❌ Exit")
        print("-" * 30)
    
    def add_task(self):
        """Add a new task"""
        print("\n➕ Adding New Task")
        title = input("Task Title: ").strip()
        if not title:
            print("❌ Title cannot be empty")
            return
        
        topic = input("Topic/Subject: ").strip()
        if not topic:
            print("❌ Topic cannot be empty")
            return
        
        print("Date (YYYY-MM-DD) [Enter for today]: ", end="")
        date_input = input().strip()
        task_date = date_input if date_input else self.current_date
        
        print("Difficulty (1=Easy, 2=Medium, 3=Hard) [2]: ", end="")
        difficulty_input = input().strip()
        difficulty_map = {"1": DifficultyLevel.EASY, "2": DifficultyLevel.MEDIUM, "3": DifficultyLevel.HARD}
        difficulty = difficulty_map.get(difficulty_input, DifficultyLevel.MEDIUM)
        
        # Create and save task
        task = Task(
            title=title,
            topic=topic,
            date=task_date,
            difficulty=difficulty
        )
        
        try:
            task_id = self.db_manager.add_task(task)
            print(f"✅ Task added successfully (ID: {task_id})")
        except Exception as e:
            print(f"❌ Failed to add task: {e}")
    
    def view_today_tasks(self):
        """View today's tasks"""
        tasks = self.db_manager.get_tasks_by_date(self.current_date)
        
        print(f"\n📅 Tasks for {self.current_date}:")
        if not tasks:
            print("   No tasks found for today")
            return
        
        for i, task in enumerate(tasks, 1):
            status_icon = "✅" if task.is_done else ("⏳" if task.progress > 0 else "📝")
            print(f"   {i}. {status_icon} {task.title}")
            print(f"      Topic: {task.topic} | Progress: {task.progress}% | Difficulty: {task.difficulty.value.title()}")
    
    def view_overdue_tasks(self):
        """View related overdue tasks"""
        # Get today's topics
        today_tasks = self.db_manager.get_tasks_by_date(self.current_date)
        today_topics = [task.topic for task in today_tasks]
        
        overdue_tasks = self.db_manager.get_overdue_tasks_by_topics(today_topics, self.current_date)
        
        print(f"\n⚠️  Related Overdue Tasks:")
        if not overdue_tasks:
            print("   No related overdue tasks found")
            return
        
        for i, task in enumerate(overdue_tasks, 1):
            warning = " ⚠️" if task.needs_warning else ""
            print(f"   {i}. {task.title}{warning}")
            print(f"      Topic: {task.topic} | Date: {task.date} | Overdue: {task.days_overdue} days")
            print(f"      Progress: {task.progress}% | Difficulty: {task.difficulty.value.title()}")
    
    def log_progress(self):
        """Log progress for tasks"""
        # Get today's tasks
        today_tasks = self.db_manager.get_tasks_by_date(self.current_date)
        
        if not today_tasks:
            print("❌ No tasks found for today")
            return
        
        # Get topics and related overdue tasks
        today_topics = [task.topic for task in today_tasks]
        overdue_tasks = self.db_manager.get_overdue_tasks_by_topics(today_topics, self.current_date)
        
        # Combine tasks
        all_tasks = today_tasks + overdue_tasks
        
        print(f"\n📊 Progress Logging Session")
        print(f"Processing {len(all_tasks)} tasks...")
        
        for i, task in enumerate(all_tasks, 1):
            print(f"\n--- Task {i}/{len(all_tasks)} ---")
            print(f"Title: {task.title}")
            print(f"Topic: {task.topic}")
            print(f"Date: {task.date}")
            
            # Ask completion question
            while True:
                completed = input("Was this task completed? (y/n): ").lower().strip()
                if completed in ['y', 'yes', 'n', 'no']:
                    break
                print("Please enter 'y' for yes or 'n' for no")
            
            is_completed = completed in ['y', 'yes']
            
            if is_completed:
                # Ask for progress and difficulty
                while True:
                    try:
                        progress = int(input("Progress percentage (0-100): "))
                        if 0 <= progress <= 100:
                            break
                        print("Please enter a number between 0 and 100")
                    except ValueError:
                        print("Please enter a valid number")
                
                print("Difficulty level:")
                print("1. Easy")
                print("2. Medium") 
                print("3. Hard")
                while True:
                    difficulty_choice = input("Select difficulty (1-3): ").strip()
                    if difficulty_choice in ['1', '2', '3']:
                        break
                    print("Please enter 1, 2, or 3")
                
                difficulty_map = {"1": DifficultyLevel.EASY, "2": DifficultyLevel.MEDIUM, "3": DifficultyLevel.HARD}
                difficulty = difficulty_map[difficulty_choice]
            else:
                progress = 0
                difficulty = task.difficulty
            
            # Update task
            task.is_done = is_completed
            task.progress = progress
            task.difficulty = difficulty
            
            try:
                self.db_manager.update_task(task)
                print(f"✅ Progress logged for '{task.title}'")
            except Exception as e:
                print(f"❌ Failed to update task: {e}")
        
        print(f"\n🎉 Progress logging completed for {len(all_tasks)} tasks!")
    
    def view_reports(self):
        """View reports"""
        print("\n📈 Select Report Type:")
        print("1. Daily Report")
        print("2. Weekly Report")
        print("3. Monthly Report")
        print("4. Full Report")
        
        choice = input("Enter choice (1-4): ").strip()
        
        if choice == "1":
            start_date = end_date = self.current_date
            report_name = "Daily"
        elif choice == "2":
            today = datetime.strptime(self.current_date, "%Y-%m-%d")
            start_date = (today - timedelta(days=7)).strftime("%Y-%m-%d")
            end_date = self.current_date
            report_name = "Weekly"
        elif choice == "3":
            today = datetime.strptime(self.current_date, "%Y-%m-%d")
            start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")
            end_date = self.current_date
            report_name = "Monthly"
        elif choice == "4":
            # Get all data range
            all_tasks = self.db_manager.get_tasks_date_range("2020-01-01", "2030-12-31")
            if all_tasks:
                start_date = min(task.date for task in all_tasks)
                end_date = max(task.date for task in all_tasks)
            else:
                start_date = end_date = self.current_date
            report_name = "Full"
        else:
            print("❌ Invalid choice")
            return
        
        try:
            total, completed, avg_progress = self.db_manager.get_completion_stats(start_date, end_date)
            completion_rate = (completed / total * 100) if total > 0 else 0
            
            print(f"\n📊 {report_name} Report")
            print("=" * 40)
            print(f"Period: {start_date} to {end_date}")
            print(f"Total Tasks: {total}")
            print(f"Completed Tasks: {completed}")
            print(f"Completion Rate: {completion_rate:.1f}%")
            print(f"Average Progress: {avg_progress:.1f}%")
            
        except Exception as e:
            print(f"❌ Failed to generate report: {e}")
    
    def change_date(self):
        """Change current date"""
        new_date = input(f"Enter new date (YYYY-MM-DD) [current: {self.current_date}]: ").strip()
        if new_date:
            try:
                # Validate date format
                datetime.strptime(new_date, "%Y-%m-%d")
                self.current_date = new_date
                print(f"✅ Date changed to {new_date}")
            except ValueError:
                print("❌ Invalid date format. Use YYYY-MM-DD")
    
    def create_backup(self):
        """Create database backup"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"data/backups/demo_backup_{timestamp}.db"
            
            os.makedirs("data/backups", exist_ok=True)
            self.db_manager.backup_database(backup_path)
            print(f"✅ Backup created: {backup_path}")
            
        except Exception as e:
            print(f"❌ Failed to create backup: {e}")
    
    def test_notification(self):
        """Test notification system"""
        print("\n🔔 Testing notification system...")
        self.notification_manager.show_notification(
            "Study Tracker Demo",
            "This is a test notification from the Study Tracker demo!"
        )
        print("✅ Notification sent (check your system notifications)")
    
    def run(self):
        """Run the demo"""
        print("Welcome to Study Tracker!")
        print("This demo shows all the core features of the application.")
        
        while True:
            self.show_menu()
            choice = input("Enter your choice (1-9): ").strip()
            
            if choice == "1":
                self.add_task()
            elif choice == "2":
                self.view_today_tasks()
            elif choice == "3":
                self.view_overdue_tasks()
            elif choice == "4":
                self.log_progress()
            elif choice == "5":
                self.view_reports()
            elif choice == "6":
                self.change_date()
            elif choice == "7":
                self.create_backup()
            elif choice == "8":
                self.test_notification()
            elif choice == "9":
                print("\n👋 Thank you for using Study Tracker Demo!")
                break
            else:
                print("❌ Invalid choice. Please enter 1-9.")

def main():
    """Main entry point for demo"""
    try:
        demo = StudyTrackerDemo()
        demo.run()
    except KeyboardInterrupt:
        print("\n\n👋 Demo interrupted by user. Goodbye!")
    except Exception as e:
        print(f"\n❌ Demo error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)