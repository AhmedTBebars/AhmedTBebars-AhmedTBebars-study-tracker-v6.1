# Study Tracker

A comprehensive desktop study tracking application with PySide6 GUI, featuring smart task management, progress logging, background notifications, and local SQLite storage.

![Study Tracker](assets/icon.svg)

## Features

### 📋 Smart Task Management
- **Daily Tasks View**: Display today's tasks sorted by order with drag-and-drop reordering
- **Smart Overdue Filtering**: Show only overdue tasks related to today's task topics
- **Task Operations**: Add, delete, reschedule tasks with intuitive dialogs
- **Manual Reordering**: Drag-and-drop or arrow buttons to reorder tasks with database persistence
- **Visual Indicators**: 
  - ✔️ Green for completed tasks
  - ⚠️ Orange/red for overdue tasks
  - ⏳ Blue for in-progress tasks
  - ⚠️ Warning symbol for tasks overdue > 7 days

### 📝 Progress Logging System
- **Intelligent Workflow**: Ask about each task in order (today's tasks first, then related overdue)
- **Conditional Questions**: 
  - If "No" → Mark as incomplete immediately
  - If "Yes" → Ask for progress percentage (0-100%) and difficulty level
- **Real-time Updates**: Database updates immediately after each response

### 📊 Reports & Charts
- **Multiple Report Types**: Daily, weekly, monthly, and full reports
- **Visual Charts**: 
  - Daily progress tracking
  - Week-to-week comparisons with dual colored lines
  - Month-to-month comparisons
- **Calendar Integration**: Select any date to view tasks and reports

### 🔔 Background Notifications
- **System Notifications**: Native OS notifications with "Study Tracker" branding
- **Persistent Service**: Notifications continue even when GUI is closed
- **Smart Reminders**: 
  - Overdue task alerts
  - Daily study reminders
  - Task deadline notifications

### 🎨 Professional UI Design
- **Clean Layout**: Separate panels for today's tasks and overdue tasks
- **Menu Bar Navigation**: 
  - Reports → Daily, Weekly, Monthly, Full
  - Charts → Daily Progress, Weekly Comparison, Monthly Comparison
  - Calendar → Date selection for historical views
- **System Tray**: Minimize to tray with quick actions
- **Responsive Design**: Resizable interface with proper scaling

### 🔒 Privacy & Security
- **100% Local**: All data stored locally in SQLite database
- **No Internet Required**: Completely offline operation
- **Data Privacy**: No external APIs or data transmission
- **Automatic Backups**: Local database backups with timestamp

## Installation

### Prerequisites
- Python 3.8 or higher
- Operating System: Windows, macOS, or Linux

### Setup
1. **Clone or download the project**:
   ```bash
   git clone <repository-url>
   cd StudyTracker
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**:
   ```bash
   python main.py
   