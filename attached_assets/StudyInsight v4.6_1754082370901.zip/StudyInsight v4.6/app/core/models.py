"""
Data models for Study Tracker
Defines task structures and enums
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
from datetime import datetime, timedelta


class TaskStatus(Enum):
    """Task completion status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class DifficultyLevel(Enum):
    """Task difficulty levels"""
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


@dataclass
class Task:
    """Task data model"""
    title: str
    topic: str
    date: str
    difficulty: DifficultyLevel = DifficultyLevel.MEDIUM
    is_done: bool = False
    progress: int = 0
    order_index: int = 0
    id: Optional[int] = None
    
    @property
    def status(self) -> TaskStatus:
        """Get task status based on completion and progress"""
        if self.is_done:
            return TaskStatus.COMPLETED
        elif self.progress > 0:
            return TaskStatus.IN_PROGRESS
        else:
            return TaskStatus.PENDING
    
    @property
    def is_overdue(self) -> bool:
        """Check if task is overdue"""
        today = datetime.now().strftime("%Y-%m-%d")
        return self.date < today and not self.is_done
    
    @property
    def days_overdue(self) -> int:
        """Get number of days overdue"""
        if not self.is_overdue:
            return 0
        
        today = datetime.now().date()
        task_date = datetime.strptime(self.date, "%Y-%m-%d").date()
        return (today - task_date).days
    
    @property
    def needs_warning(self) -> bool:
        """Check if task needs warning (overdue > 7 days)"""
        return self.days_overdue > 7
    
    def __str__(self) -> str:
        return f"{self.title} ({self.topic}) - {self.date}"
    
    def __repr__(self) -> str:
        return f"Task(id={self.id}, title='{self.title}', topic='{self.topic}', date='{self.date}')"


@dataclass
class ProgressEntry:
    """Progress logging entry"""
    task_id: int
    completed: bool
    progress_percentage: int = 0
    difficulty_rating: DifficultyLevel = DifficultyLevel.MEDIUM
    timestamp: Optional[str] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()


@dataclass
class DailyStats:
    """Daily statistics"""
    date: str
    total_tasks: int
    completed_tasks: int
    average_progress: float
    
    @property
    def completion_rate(self) -> float:
        """Calculate completion rate as percentage"""
        if self.total_tasks == 0:
            return 0.0
        return (self.completed_tasks / self.total_tasks) * 100
