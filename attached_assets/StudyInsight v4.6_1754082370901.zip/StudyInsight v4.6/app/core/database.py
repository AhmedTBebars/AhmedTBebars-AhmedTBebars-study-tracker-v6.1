"""
Database management for Study Tracker
Handles SQLite operations and database initialization
"""

import sqlite3
import os
from datetime import datetime
from typing import List, Optional, Tuple
from .models import Task, TaskStatus, DifficultyLevel


class DatabaseManager:
    def __init__(self, db_path: str = "data/study_tracker.db"):
        """Initialize database manager"""
        self.db_path = db_path
        self._ensure_data_directory()
        self._init_database()
    
    def _ensure_data_directory(self):
        """Ensure data directory exists"""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
    
    def _init_database(self):
        """Initialize database tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create tasks table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    title TEXT NOT NULL,
                    topic TEXT NOT NULL,
                    is_done INTEGER DEFAULT 0,
                    progress INTEGER DEFAULT 0,
                    difficulty TEXT DEFAULT 'medium',
                    order_index INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create index for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_date ON tasks(date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_topic ON tasks(topic)")
            
            conn.commit()
    
    def add_task(self, task: Task) -> int:
        """Add a new task to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get max order_index for the date
            cursor.execute(
                "SELECT COALESCE(MAX(order_index), -1) FROM tasks WHERE date = ?",
                (task.date,)
            )
            max_order = cursor.fetchone()[0]
            task.order_index = max_order + 1
            
            cursor.execute("""
                INSERT INTO tasks (date, title, topic, is_done, progress, difficulty, order_index)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                task.date, task.title, task.topic, 
                int(task.is_done), task.progress, task.difficulty.value, task.order_index
            ))
            
            task_id = cursor.lastrowid
            conn.commit()
            return task_id
    
    def get_tasks_by_date(self, date: str) -> List[Task]:
        """Get all tasks for a specific date"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, date, title, topic, is_done, progress, difficulty, order_index
                FROM tasks 
                WHERE date = ? 
                ORDER BY order_index ASC
            """, (date,))
            
            return [self._row_to_task(row) for row in cursor.fetchall()]
    
    def get_overdue_tasks_by_topics(self, topics: List[str], current_date: str) -> List[Task]:
        """Get overdue tasks that match given topics"""
        if not topics:
            return []
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            placeholders = ','.join(['?' for _ in topics])
            cursor.execute(f"""
                SELECT id, date, title, topic, is_done, progress, difficulty, order_index
                FROM tasks 
                WHERE date < ? AND topic IN ({placeholders}) AND is_done = 0
                ORDER BY date ASC, order_index ASC
            """, [current_date] + topics)
            
            return [self._row_to_task(row) for row in cursor.fetchall()]
    
    def update_task(self, task: Task):
        """Update an existing task"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE tasks 
                SET date = ?, title = ?, topic = ?, is_done = ?, progress = ?, 
                    difficulty = ?, order_index = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (
                task.date, task.title, task.topic, int(task.is_done), 
                task.progress, task.difficulty.value, task.order_index, task.id
            ))
            conn.commit()
    
    def delete_task(self, task_id: int):
        """Delete a task by ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
            conn.commit()
    
    def update_task_order(self, task_id: int, new_order: int, date: str):
        """Update task order index"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE tasks 
                SET order_index = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND date = ?
            """, (new_order, task_id, date))
            conn.commit()
    
    def reschedule_task(self, task_id: int, new_date: str):
        """Reschedule a task to a new date"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get max order_index for the new date
            cursor.execute(
                "SELECT COALESCE(MAX(order_index), -1) FROM tasks WHERE date = ?",
                (new_date,)
            )
            max_order = cursor.fetchone()[0]
            
            cursor.execute("""
                UPDATE tasks 
                SET date = ?, order_index = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (new_date, max_order + 1, task_id))
            conn.commit()
    
    def get_tasks_date_range(self, start_date: str, end_date: str) -> List[Task]:
        """Get tasks within a date range"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, date, title, topic, is_done, progress, difficulty, order_index
                FROM tasks 
                WHERE date >= ? AND date <= ?
                ORDER BY date ASC, order_index ASC
            """, (start_date, end_date))
            
            return [self._row_to_task(row) for row in cursor.fetchall()]
    
    def get_completion_stats(self, start_date: str, end_date: str) -> Tuple[int, int, float]:
        """Get completion statistics for date range"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(is_done) as completed,
                    AVG(CASE WHEN is_done = 1 THEN progress ELSE 0 END) as avg_progress
                FROM tasks 
                WHERE date >= ? AND date <= ?
            """, (start_date, end_date))
            
            result = cursor.fetchone()
            total = result[0] or 0
            completed = result[1] or 0
            avg_progress = result[2] or 0.0
            
            return total, completed, avg_progress
    
    def get_daily_progress(self, start_date: str, end_date: str) -> List[Tuple[str, int, int]]:
        """Get daily progress data for chart"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT 
                    date,
                    COUNT(*) as total,
                    SUM(is_done) as completed
                FROM tasks 
                WHERE date >= ? AND date <= ?
                GROUP BY date
                ORDER BY date ASC
            """, (start_date, end_date))
            
            return cursor.fetchall()
    
    def backup_database(self, backup_path: str):
        """Create a backup of the database"""
        import shutil
        shutil.copy2(self.db_path, backup_path)
    
    def _row_to_task(self, row) -> Task:
        """Convert database row to Task object"""
        return Task(
            id=row[0],
            date=row[1],
            title=row[2],
            topic=row[3],
            is_done=bool(row[4]),
            progress=row[5],
            difficulty=DifficultyLevel(row[6]),
            order_index=row[7]
        )
