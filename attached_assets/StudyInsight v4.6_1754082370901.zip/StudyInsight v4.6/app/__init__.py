"""
Study Tracker Application Package
A comprehensive desktop study tracking application with PySide6 GUI
"""

__version__ = "1.0.0"
__author__ = "Study Tracker Team"
__description__ = "Desktop study tracking application with smart task management"
