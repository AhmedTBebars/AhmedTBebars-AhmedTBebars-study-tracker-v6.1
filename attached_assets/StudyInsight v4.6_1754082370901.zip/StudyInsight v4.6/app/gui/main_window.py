"""
Main window for Study Tracker application
"""

import sys
from datetime import datetime, timedelta
from typing import List

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QPushButton, QMenuBar, QMenu, QApplication, QMessageBox,
    QSplitter, QFrame, QScrollArea, QFileDialog
)
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QAction, QFont, QPixmap, QIcon

from ..core.database import DatabaseManager
from ..core.models import Task, DifficultyLevel
from .dialogs import AddTaskDialog, ProgressDialog, CalendarDialog
from .widgets import TaskListWidget
from .charts import ChartWindow
from ..features.notifications import NotificationManager
from ..features.scheduler import TaskScheduler


class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.db_manager = DatabaseManager()
        self.notification_manager = NotificationManager()
        self.scheduler = TaskScheduler(self.db_manager, self.notification_manager)
        
        self.current_date = datetime.now().strftime("%Y-%m-%d")
        self.chart_window = None
        
        self.init_ui()
        self.load_tasks()
        self.start_scheduler()
    
    def init_ui(self):
        """Initialize user interface"""
        self.setWindowTitle("Study Tracker - Desktop Task Manager")
        self.setGeometry(100, 100, 1200, 800)
        
        # Set application icon
        try:
            self.setWindowIcon(QIcon("assets/icon.svg"))
        except:
            pass  # Icon file might not exist yet
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout(central_widget)
        
        # Header
        header_layout = QHBoxLayout()
        
        # Title and date
        title_label = QLabel("Study Tracker")
        title_font = QFont()
        title_font.setPointSize(18)
        title_font.setBold(True)
        title_label.setFont(title_font)
        
        date_label = QLabel(f"Today: {self.current_date}")
        date_font = QFont()
        date_font.setPointSize(12)
        date_label.setFont(date_font)
        
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(date_label)
        
        main_layout.addLayout(header_layout)
        
        # Action buttons
        button_layout = QHBoxLayout()
        
        self.add_task_btn = QPushButton("➕ Add Task")
        self.add_task_btn.clicked.connect(self.add_task)
        
        self.log_progress_btn = QPushButton("📝 Log Progress")
        self.log_progress_btn.clicked.connect(self.log_progress)
        
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.load_tasks)
        
        button_layout.addWidget(self.add_task_btn)
        button_layout.addWidget(self.log_progress_btn)
        button_layout.addWidget(self.refresh_btn)
        button_layout.addStretch()
        
        main_layout.addLayout(button_layout)
        
        # Task panels
        splitter = QSplitter(Qt.Horizontal)
        
        # Today's tasks panel
        today_frame = QFrame()
        today_frame.setFrameStyle(QFrame.StyledPanel)
        today_layout = QVBoxLayout(today_frame)
        
        today_title = QLabel("📅 Today's Tasks")
        today_title_font = QFont()
        today_title_font.setPointSize(14)
        today_title_font.setBold(True)
        today_title.setFont(today_title_font)
        today_layout.addWidget(today_title)
        
        # Today's task list
        self.today_tasks_widget = TaskListWidget(self.db_manager)
        self.today_tasks_widget.task_updated.connect(self.load_tasks)
        today_layout.addWidget(self.today_tasks_widget)
        
        # Overdue tasks panel
        overdue_frame = QFrame()
        overdue_frame.setFrameStyle(QFrame.StyledPanel)
        overdue_layout = QVBoxLayout(overdue_frame)
        
        overdue_title = QLabel("⚠️ Related Overdue Tasks")
        overdue_title_font = QFont()
        overdue_title_font.setPointSize(14)
        overdue_title_font.setBold(True)
        overdue_title.setFont(overdue_title_font)
        overdue_layout.addWidget(overdue_title)
        
        # Overdue task list
        self.overdue_tasks_widget = TaskListWidget(self.db_manager)
        self.overdue_tasks_widget.task_updated.connect(self.load_tasks)
        overdue_layout.addWidget(self.overdue_tasks_widget)
        
        splitter.addWidget(today_frame)
        splitter.addWidget(overdue_frame)
        splitter.setSizes([600, 600])
        
        main_layout.addWidget(splitter)
        
        # Status bar
        self.statusBar().showMessage("Ready")
    
    def create_menu_bar(self):
        """Create application menu bar"""
        menubar = self.menuBar()
        
        # Reports menu
        reports_menu = menubar.addMenu("📊 Reports")
        
        daily_action = QAction("Daily Report", self)
        daily_action.triggered.connect(lambda: self.show_report("daily"))
        reports_menu.addAction(daily_action)
        
        weekly_action = QAction("Weekly Report", self)
        weekly_action.triggered.connect(lambda: self.show_report("weekly"))
        reports_menu.addAction(weekly_action)
        
        monthly_action = QAction("Monthly Report", self)
        monthly_action.triggered.connect(lambda: self.show_report("monthly"))
        reports_menu.addAction(monthly_action)
        
        full_action = QAction("Full Report", self)
        full_action.triggered.connect(lambda: self.show_report("full"))
        reports_menu.addAction(full_action)
        
        # Charts menu
        charts_menu = menubar.addMenu("📈 Charts")
        
        daily_progress_action = QAction("Daily Progress", self)
        daily_progress_action.triggered.connect(lambda: self.show_chart("daily_progress"))
        charts_menu.addAction(daily_progress_action)
        
        weekly_comparison_action = QAction("Weekly Comparison", self)
        weekly_comparison_action.triggered.connect(lambda: self.show_chart("weekly_comparison"))
        charts_menu.addAction(weekly_comparison_action)
        
        monthly_comparison_action = QAction("Monthly Comparison", self)
        monthly_comparison_action.triggered.connect(lambda: self.show_chart("monthly_comparison"))
        charts_menu.addAction(monthly_comparison_action)
        
        # Calendar menu
        calendar_menu = menubar.addMenu("📅 Calendar")
        
        select_date_action = QAction("Select Date", self)
        select_date_action.triggered.connect(self.show_calendar)
        calendar_menu.addAction(select_date_action)
        
        # Settings menu
        settings_menu = menubar.addMenu("⚙️ Settings")
        
        notifications_action = QAction("Notification Settings", self)
        notifications_action.triggered.connect(self.show_notification_settings)
        settings_menu.addAction(notifications_action)
        
        settings_menu.addSeparator()
        
        import_csv_action = QAction("📄 Import CSV", self)
        import_csv_action.triggered.connect(self.import_csv)
        settings_menu.addAction(import_csv_action)
        
        backup_action = QAction("Backup Data", self)
        backup_action.triggered.connect(self.backup_data)
        settings_menu.addAction(backup_action)
    
    def add_task(self):
        """Show add task dialog"""
        dialog = AddTaskDialog(self)
        if dialog.exec():
            task_data = dialog.get_task_data()
            task = Task(
                title=task_data['title'],
                topic=task_data['topic'],
                date=task_data['date'],
                difficulty=task_data['difficulty']
            )
            
            try:
                self.db_manager.add_task(task)
                self.load_tasks()
                self.statusBar().showMessage(f"Task '{task.title}' added successfully", 3000)
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to add task: {str(e)}")
    
    def log_progress(self):
        """Start progress logging session"""
        # Get today's tasks
        today_tasks = self.db_manager.get_tasks_by_date(self.current_date)
        
        if not today_tasks:
            QMessageBox.information(self, "No Tasks", "No tasks found for today.")
            return
        
        # Get topics from today's tasks
        today_topics = [task.topic for task in today_tasks]
        
        # Get related overdue tasks
        overdue_tasks = self.db_manager.get_overdue_tasks_by_topics(today_topics, self.current_date)
        
        # Combine tasks in order: today's tasks first, then overdue
        all_tasks = today_tasks + overdue_tasks
        
        if not all_tasks:
            QMessageBox.information(self, "No Tasks", "No tasks found to log progress.")
            return
        
        # Start progress logging
        self.progress_logging_tasks = all_tasks
        self.current_progress_index = 0
        self.log_next_task()
    
    def log_next_task(self):
        """Log progress for the next task"""
        if self.current_progress_index >= len(self.progress_logging_tasks):
            QMessageBox.information(self, "Complete", "Progress logging completed!")
            self.load_tasks()
            return
        
        task = self.progress_logging_tasks[self.current_progress_index]
        dialog = ProgressDialog(task, self)
        
        if dialog.exec():
            progress_data = dialog.get_progress_data()
            
            # Update task
            task.is_done = progress_data['completed']
            task.progress = progress_data['progress']
            task.difficulty = progress_data['difficulty']
            
            try:
                self.db_manager.update_task(task)
                self.statusBar().showMessage(f"Progress logged for '{task.title}'", 2000)
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to update task: {str(e)}")
        
        self.current_progress_index += 1
        self.log_next_task()
    
    def load_tasks(self):
        """Load and display tasks"""
        try:
            # Load today's tasks
            today_tasks = self.db_manager.get_tasks_by_date(self.current_date)
            self.today_tasks_widget.load_tasks(today_tasks)
            
            # Get topics from today's tasks
            today_topics = [task.topic for task in today_tasks]
            
            # Load related overdue tasks
            overdue_tasks = self.db_manager.get_overdue_tasks_by_topics(today_topics, self.current_date)
            self.overdue_tasks_widget.load_tasks(overdue_tasks)
            
            # Update status bar
            total_today = len(today_tasks)
            completed_today = sum(1 for task in today_tasks if task.is_done)
            total_overdue = len(overdue_tasks)
            
            status_msg = f"Today: {completed_today}/{total_today} completed"
            if total_overdue > 0:
                status_msg += f" | Overdue: {total_overdue}"
            
            self.statusBar().showMessage(status_msg)
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to load tasks: {str(e)}")
    
    def show_report(self, report_type: str):
        """Show report based on type"""
        try:
            if report_type == "daily":
                start_date = end_date = self.current_date
            elif report_type == "weekly":
                today = datetime.now()
                start_date = (today - timedelta(days=7)).strftime("%Y-%m-%d")
                end_date = today.strftime("%Y-%m-%d")
            elif report_type == "monthly":
                today = datetime.now()
                start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")
                end_date = today.strftime("%Y-%m-%d")
            else:  # full
                # Get all data
                tasks = self.db_manager.get_tasks_date_range("2020-01-01", "2030-12-31")
                if tasks:
                    start_date = min(task.date for task in tasks)
                    end_date = max(task.date for task in tasks)
                else:
                    start_date = end_date = self.current_date
            
            total, completed, avg_progress = self.db_manager.get_completion_stats(start_date, end_date)
            
            completion_rate = (completed / total * 100) if total > 0 else 0
            
            report_text = f"""
{report_type.upper()} REPORT
Period: {start_date} to {end_date}

Total Tasks: {total}
Completed Tasks: {completed}
Completion Rate: {completion_rate:.1f}%
Average Progress: {avg_progress:.1f}%
            """
            
            QMessageBox.information(self, f"{report_type.title()} Report", report_text)
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to generate report: {str(e)}")
    
    def show_chart(self, chart_type: str):
        """Show chart window"""
        try:
            if self.chart_window:
                self.chart_window.close()
            
            self.chart_window = ChartWindow(self.db_manager, chart_type, self)
            self.chart_window.show()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to show chart: {str(e)}")
    
    def show_calendar(self):
        """Show calendar dialog"""
        dialog = CalendarDialog(self.current_date, self)
        if dialog.exec():
            selected_date = dialog.get_selected_date()
            if selected_date != self.current_date:
                self.current_date = selected_date
                self.load_tasks()
                
                # Update date label
                for widget in self.findChildren(QLabel):
                    if widget.text().startswith("Today:"):
                        widget.setText(f"Selected: {selected_date}")
                        break
    
    def show_notification_settings(self):
        """Show notification settings"""
        QMessageBox.information(
            self, 
            "Notification Settings", 
            "Notifications are automatically enabled.\nYou will receive reminders for overdue tasks."
        )
    
    def import_csv(self):
        """Import tasks from CSV file"""
        try:
            # Open file dialog to select CSV file
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "Import Tasks from CSV",
                "",
                "CSV Files (*.csv);;All Files (*)"
            )
            
            if not file_path:
                return  # User cancelled
            
            # Import tasks from CSV
            imported_count = self._process_csv_import(file_path)
            
            if imported_count > 0:
                # Refresh the task display
                self.load_tasks()
                QMessageBox.information(
                    self, 
                    "Import Successful", 
                    f"{imported_count} tasks imported successfully!"
                )
            else:
                QMessageBox.information(
                    self, 
                    "Import Complete", 
                    "No new tasks were imported (all tasks already exist or CSV was empty)."
                )
                
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Import Error", 
                f"Failed to import CSV file:\n{str(e)}\n\nPlease check that your CSV file has the correct format:\nDate,Title,Topic,Is_Done"
            )
    
    def _process_csv_import(self, file_path: str) -> int:
        """Process CSV file and import tasks"""
        import csv
        from datetime import datetime
        
        imported_count = 0
        
        with open(file_path, 'r', encoding='utf-8') as csvfile:
            # Detect CSV dialect
            sample = csvfile.read(1024)
            csvfile.seek(0)
            dialect = csv.Sniffer().sniff(sample)
            
            reader = csv.DictReader(csvfile, dialect=dialect)
            
            # Validate required columns
            required_columns = ['Date', 'Title', 'Topic', 'Is_Done']
            if not all(col in reader.fieldnames for col in required_columns):
                raise ValueError(f"CSV must contain columns: {', '.join(required_columns)}")
            
            for row_num, row in enumerate(reader, start=2):  # Start at 2 for header
                try:
                    # Extract and validate data
                    date = row['Date'].strip()
                    title = row['Title'].strip()
                    topic = row['Topic'].strip()
                    is_done_str = row['Is_Done'].strip()
                    
                    # Validate required fields
                    if not date or not title:
                        print(f"Warning: Skipping row {row_num} - missing date or title")
                        continue
                    
                    # Validate date format
                    try:
                        datetime.strptime(date, "%Y-%m-%d")
                    except ValueError:
                        print(f"Warning: Skipping row {row_num} - invalid date format '{date}'. Use YYYY-MM-DD")
                        continue
                    
                    # Convert is_done to boolean/integer
                    is_done = 1 if is_done_str.lower() in ['1', 'true', 'yes', 'completed'] else 0
                    
                    # Set default topic if empty
                    if not topic:
                        topic = 'General'
                    
                    # Check for duplicates (same date + title)
                    existing_tasks = self.db_manager.get_tasks_by_date(date)
                    if any(task.title.lower() == title.lower() for task in existing_tasks):
                        print(f"Skipping duplicate task: '{title}' on {date}")
                        continue
                    
                    # Create task object
                    task = Task(
                        title=title,
                        topic=topic,
                        date=date,
                        difficulty=DifficultyLevel.MEDIUM,  # Default difficulty
                        is_done=bool(is_done),
                        progress=100 if is_done else 0,  # Set progress based on completion
                        order_index=0  # Will be set automatically by database
                    )
                    
                    # Add task to database
                    self.db_manager.add_task(task)
                    imported_count += 1
                    print(f"Imported: '{title}' ({topic}) on {date}")
                    
                except Exception as e:
                    print(f"Error processing row {row_num}: {e}")
                    continue
        
        return imported_count
    
    def backup_data(self):
        """Create database backup"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"data/backups/backup_{timestamp}.db"
            
            # Ensure backup directory exists
            import os
            os.makedirs("data/backups", exist_ok=True)
            
            self.db_manager.backup_database(backup_path)
            QMessageBox.information(self, "Backup", f"Database backed up to {backup_path}")
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to create backup: {str(e)}")
    
    def start_scheduler(self):
        """Start the task scheduler"""
        self.scheduler.start()
    
    def closeEvent(self, event):
        """Handle application close event"""
        # Keep scheduler running in background
        self.hide()
        event.ignore()
        
        # Show system tray notification
        self.notification_manager.show_notification(
            "Study Tracker", 
            "Application minimized to system tray. Notifications will continue."
        )
