"""
Custom widgets for Study Tracker
"""

from typing import List
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QFrame, QMenu, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QMimeData
from PySide6.QtGui import QDrag, QFont, QColor, QPalette

from ..core.database import DatabaseManager
from ..core.models import Task, TaskStatus
from .dialogs import RescheduleDialog


class TaskWidget(QWidget):
    """Widget for displaying individual tasks"""
    
    task_updated = Signal()
    
    def __init__(self, task: Task, db_manager: DatabaseManager, parent=None):
        super().__init__(parent)
        self.task = task
        self.db_manager = db_manager
        self.init_ui()
    
    def init_ui(self):
        """Initialize task widget UI"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 5, 10, 5)
        
        # Status icon
        status_icon = self.get_status_icon()
        status_label = QLabel(status_icon)
        status_label.setFixedWidth(30)
        layout.addWidget(status_label)
        
        # Task info
        info_layout = QVBoxLayout()
        
        # Title and topic
        title_text = f"{self.task.title}"
        if self.task.needs_warning:
            title_text += " ⚠️"
        
        title_label = QLabel(title_text)
        title_font = QFont()
        title_font.setBold(True)
        title_label.setFont(title_font)
        
        topic_label = QLabel(f"Topic: {self.task.topic}")
        topic_label.setStyleSheet("color: #666;")
        
        # Progress info
        progress_text = f"Progress: {self.task.progress}% | Difficulty: {self.task.difficulty.value.title()}"
        if self.task.is_overdue:
            progress_text += f" | Overdue: {self.task.days_overdue} days"
        
        progress_label = QLabel(progress_text)
        progress_label.setStyleSheet("color: #888; font-size: 10px;")
        
        info_layout.addWidget(title_label)
        info_layout.addWidget(topic_label)
        info_layout.addWidget(progress_label)
        
        layout.addLayout(info_layout)
        layout.addStretch()
        
        # Action buttons
        button_layout = QVBoxLayout()
        
        reschedule_btn = QPushButton("📅")
        reschedule_btn.setToolTip("Reschedule task")
        reschedule_btn.setFixedSize(30, 25)
        reschedule_btn.clicked.connect(self.reschedule_task)
        
        delete_btn = QPushButton("🗑️")
        delete_btn.setToolTip("Delete task")
        delete_btn.setFixedSize(30, 25)
        delete_btn.clicked.connect(self.delete_task)
        
        button_layout.addWidget(reschedule_btn)
        button_layout.addWidget(delete_btn)
        
        layout.addLayout(button_layout)
        
        # Set background color based on status
        self.set_background_color()
    
    def get_status_icon(self) -> str:
        """Get status icon for task"""
        if self.task.status == TaskStatus.COMPLETED:
            return "✔️"
        elif self.task.status == TaskStatus.IN_PROGRESS:
            return "⏳"
        elif self.task.is_overdue:
            return "⚠️"
        else:
            return "📝"
    
    def set_background_color(self):
        """Set background color based on task status"""
        if self.task.status == TaskStatus.COMPLETED:
            self.setStyleSheet("QWidget { background-color: #e8f5e8; border-radius: 5px; }")
        elif self.task.is_overdue:
            self.setStyleSheet("QWidget { background-color: #ffeaa7; border-radius: 5px; }")
        elif self.task.status == TaskStatus.IN_PROGRESS:
            self.setStyleSheet("QWidget { background-color: #e3f2fd; border-radius: 5px; }")
        else:
            self.setStyleSheet("QWidget { background-color: #f9f9f9; border-radius: 5px; }")
    
    def reschedule_task(self):
        """Reschedule task to new date"""
        dialog = RescheduleDialog(self.task, self)
        if dialog.exec():
            new_date = dialog.get_new_date()
            try:
                self.db_manager.reschedule_task(self.task.id, new_date)
                self.task_updated.emit()
                QMessageBox.information(self, "Success", f"Task rescheduled to {new_date}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to reschedule task: {str(e)}")
    
    def delete_task(self):
        """Delete task after confirmation"""
        reply = QMessageBox.question(
            self, 
            "Confirm Delete", 
            f"Are you sure you want to delete the task '{self.task.title}'?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            try:
                self.db_manager.delete_task(self.task.id)
                self.task_updated.emit()
                QMessageBox.information(self, "Success", "Task deleted successfully")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to delete task: {str(e)}")


class TaskListWidget(QListWidget):
    """Custom list widget for tasks with drag and drop support"""
    
    task_updated = Signal()
    
    def __init__(self, db_manager: DatabaseManager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.tasks = []
        self.init_ui()
    
    def init_ui(self):
        """Initialize list widget"""
        self.setDragDropMode(QListWidget.InternalMove)
        self.setDefaultDropAction(Qt.MoveAction)
        self.setAlternatingRowColors(True)
        self.setSpacing(5)
        
        # Enable context menu
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
    
    def load_tasks(self, tasks: List[Task]):
        """Load tasks into the widget"""
        self.clear()
        self.tasks = tasks
        
        if not tasks:
            # Show empty state
            item = QListWidgetItem("No tasks found")
            item.setFlags(Qt.NoItemFlags)
            item.setTextAlignment(Qt.AlignCenter)
            self.addItem(item)
            return
        
        for task in tasks:
            self.add_task_item(task)
    
    def add_task_item(self, task: Task):
        """Add a task item to the list"""
        item = QListWidgetItem()
        self.addItem(item)
        
        # Create task widget
        task_widget = TaskWidget(task, self.db_manager, self)
        task_widget.task_updated.connect(self.task_updated.emit)
        
        # Set item size to match widget
        item.setSizeHint(task_widget.sizeHint())
        
        # Add widget to item
        self.setItemWidget(item, task_widget)
    
    def show_context_menu(self, position):
        """Show context menu for tasks"""
        item = self.itemAt(position)
        if not item or not self.tasks:
            return
        
        # Get selected task
        row = self.row(item)
        if row < 0 or row >= len(self.tasks):
            return
        
        task = self.tasks[row]
        
        menu = QMenu(self)
        
        # Move up action
        if row > 0:
            move_up_action = menu.addAction("⬆️ Move Up")
            move_up_action.triggered.connect(lambda: self.move_task(row, row - 1))
        
        # Move down action
        if row < len(self.tasks) - 1:
            move_down_action = menu.addAction("⬇️ Move Down")
            move_down_action.triggered.connect(lambda: self.move_task(row, row + 1))
        
        if menu.actions():
            menu.exec(self.mapToGlobal(position))
    
    def move_task(self, from_index: int, to_index: int):
        """Move task from one position to another"""
        if from_index < 0 or from_index >= len(self.tasks):
            return
        if to_index < 0 or to_index >= len(self.tasks):
            return
        
        try:
            # Update order in database
            task = self.tasks[from_index]
            
            # Swap order indices
            if from_index < to_index:
                # Moving down
                for i in range(from_index + 1, to_index + 1):
                    self.tasks[i].order_index -= 1
                    self.db_manager.update_task_order(
                        self.tasks[i].id, 
                        self.tasks[i].order_index, 
                        self.tasks[i].date
                    )
            else:
                # Moving up
                for i in range(to_index, from_index):
                    self.tasks[i].order_index += 1
                    self.db_manager.update_task_order(
                        self.tasks[i].id, 
                        self.tasks[i].order_index, 
                        self.tasks[i].date
                    )
            
            # Update moved task
            task.order_index = to_index
            self.db_manager.update_task_order(task.id, task.order_index, task.date)
            
            # Refresh display
            self.task_updated.emit()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to move task: {str(e)}")
    
    def dropEvent(self, event):
        """Handle drop events for drag and drop"""
        source_item = self.currentItem()
        if not source_item:
            return
        
        # Get source and target indices
        source_row = self.row(source_item)
        
        # Let the parent handle the move
        super().dropEvent(event)
        
        # Get new position
        target_row = self.row(source_item)
        
        if source_row != target_row and source_row >= 0 and target_row >= 0:
            self.move_task(source_row, target_row)
