"""
Dialog windows for Study Tracker
"""

from datetime import datetime
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QDateEdit, QTextEdit, QDialogButtonBox as QButtonBox,
    QSpinBox, QRadioButton, QButtonGroup, QCalendarWidget,
    QMessageBox, QFormLayout, QWidget
)
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QFont

from ..core.models import Task, DifficultyLevel


class AddTaskDialog(QDialog):
    """Dialog for adding new tasks"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
    
    def init_ui(self):
        """Initialize dialog UI"""
        self.setWindowTitle("Add New Task")
        self.setModal(True)
        self.resize(400, 300)
        
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()
        
        # Task title
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Enter task title...")
        form_layout.addRow("Task Title:", self.title_edit)
        
        # Task topic
        self.topic_edit = QLineEdit()
        self.topic_edit.setPlaceholderText("Enter task topic/subject...")
        form_layout.addRow("Topic:", self.topic_edit)
        
        # Date selection
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        form_layout.addRow("Date:", self.date_edit)
        
        # Difficulty selection
        self.difficulty_combo = QComboBox()
        self.difficulty_combo.addItems(["Easy", "Medium", "Hard"])
        self.difficulty_combo.setCurrentText("Medium")
        form_layout.addRow("Difficulty:", self.difficulty_combo)
        
        layout.addLayout(form_layout)
        
        # Buttons
        button_box = QButtonBox(QButtonBox.Ok | QButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Focus on title
        self.title_edit.setFocus()
    
    def get_task_data(self):
        difficulty_map = {
            "Easy": DifficultyLevel.EASY,
            "Medium": DifficultyLevel.MEDIUM,
            "Hard": DifficultyLevel.HARD
        }
        return {
            'title': self.title_edit.text().strip(),
            'topic': self.topic_edit.text().strip(),
            'date': self.date_edit.date().toString("yyyy-MM-dd"),
            'difficulty': difficulty_map[self.difficulty_combo.currentText()]
        }
    
    def accept(self):
        if not self.title_edit.text().strip():
            QMessageBox.warning(self, "Invalid Input", "Please enter a task title.")
            return
        if not self.topic_edit.text().strip():
            QMessageBox.warning(self, "Invalid Input", "Please enter a task topic.")
            return
        super().accept()


class ProgressDialog(QDialog):
    """Dialog for logging task progress"""
    
    def __init__(self, task: Task, parent=None):
        super().__init__(parent)
        self.task = task
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Log Progress")
        self.setModal(True)
        self.resize(400, 350)
        
        layout = QVBoxLayout(self)
        
        # Task info
        task_info = QLabel(f"Task: {self.task.title}\nTopic: {self.task.topic}\nDate: {self.task.date}")
        task_font = QFont()
        task_font.setBold(True)
        task_info.setFont(task_font)
        layout.addWidget(task_info)
        
        # Completion question
        completion_label = QLabel("Was this task completed?")
        completion_font = QFont()
        completion_font.setPointSize(12)
        completion_label.setFont(completion_font)
        layout.addWidget(completion_label)
        
        # Yes/No buttons
        self.completion_group = QButtonGroup()
        completion_layout = QHBoxLayout()
        
        self.yes_radio = QRadioButton("Yes ✓")
        self.no_radio = QRadioButton("No ✗")
        self.completion_group.addButton(self.yes_radio, 1)
        self.completion_group.addButton(self.no_radio, 0)
        
        completion_layout.addWidget(self.yes_radio)
        completion_layout.addWidget(self.no_radio)
        completion_layout.addStretch()
        layout.addLayout(completion_layout)
        
        # Progress section
        self.progress_widget = QWidget()
        progress_layout = QVBoxLayout(self.progress_widget)
        
        progress_label = QLabel("Progress Percentage (0-100%):")
        progress_layout.addWidget(progress_label)
        
        self.progress_spin = QSpinBox()
        self.progress_spin.setRange(0, 100)
        self.progress_spin.setValue(100)
        self.progress_spin.setSuffix("%")
        progress_layout.addWidget(self.progress_spin)
        
        difficulty_label = QLabel("Difficulty Level:")
        progress_layout.addWidget(difficulty_label)
        
        self.difficulty_combo = QComboBox()
        self.difficulty_combo.addItems(["Easy", "Medium", "Hard"])
        self.difficulty_combo.setCurrentText(self.task.difficulty.value.title())
        progress_layout.addWidget(self.difficulty_combo)
        
        layout.addWidget(self.progress_widget)
        self.progress_widget.hide()
        
        # Signals
        self.yes_radio.toggled.connect(self.on_completion_changed)
        self.no_radio.toggled.connect(self.on_completion_changed)
        
        # Buttons
        button_box = QButtonBox(QButtonBox.Ok | QButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        self.no_radio.setChecked(True)
    
    def on_completion_changed(self):
        if self.yes_radio.isChecked():
            self.progress_widget.show()
        else:
            self.progress_widget.hide()
    
    def get_progress_data(self):
        difficulty_map = {
            "Easy": DifficultyLevel.EASY,
            "Medium": DifficultyLevel.MEDIUM,
            "Hard": DifficultyLevel.HARD
        }
        completed = self.yes_radio.isChecked()
        progress = self.progress_spin.value() if completed else 0
        difficulty = difficulty_map[self.difficulty_combo.currentText()]
        return {
            'completed': completed,
            'progress': progress,
            'difficulty': difficulty
        }
    
    def accept(self):
        if not self.yes_radio.isChecked() and not self.no_radio.isChecked():
            QMessageBox.warning(self, "Invalid Input", "Please select whether the task was completed.")
            return
        super().accept()


class CalendarDialog(QDialog):
    """Dialog for selecting dates"""
    
    def __init__(self, current_date: str, parent=None):
        super().__init__(parent)
        self.current_date = current_date
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Select Date")
        self.setModal(True)
        self.resize(400, 300)
        
        layout = QVBoxLayout(self)
        instruction_label = QLabel("Select a date to view tasks and reports:")
        layout.addWidget(instruction_label)
        
        self.calendar = QCalendarWidget()
        current_qdate = QDate.fromString(self.current_date, "yyyy-MM-dd")
        self.calendar.setSelectedDate(current_qdate)
        layout.addWidget(self.calendar)
        
        button_layout = QHBoxLayout()
        today_btn = QPushButton("Today")
        today_btn.clicked.connect(self.select_today)
        
        button_box = QButtonBox(QButtonBox.Ok | QButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        
        button_layout.addWidget(today_btn)
        button_layout.addStretch()
        button_layout.addWidget(button_box)
        layout.addLayout(button_layout)
    
    def select_today(self):
        self.calendar.setSelectedDate(QDate.currentDate())
    
    def get_selected_date(self) -> str:
        return self.calendar.selectedDate().toString("yyyy-MM-dd")


class RescheduleDialog(QDialog):
    """Dialog for rescheduling tasks"""
    
    def __init__(self, task: Task, parent=None):
        super().__init__(parent)
        self.task = task
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Reschedule Task")
        self.setModal(True)
        self.resize(350, 200)
        
        layout = QVBoxLayout(self)
        task_info = QLabel(f"Task: {self.task.title}\nCurrent Date: {self.task.date}")
        task_font = QFont()
        task_font.setBold(True)
        task_info.setFont(task_font)
        layout.addWidget(task_info)
        
        form_layout = QFormLayout()
        self.new_date_edit = QDateEdit()
        self.new_date_edit.setDate(QDate.currentDate())
        self.new_date_edit.setCalendarPopup(True)
        form_layout.addRow("New Date:", self.new_date_edit)
        layout.addLayout(form_layout)
        
        button_box = QButtonBox(QButtonBox.Ok | QButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def get_new_date(self) -> str:
        return self.new_date_edit.date().toString("yyyy-MM-dd")
