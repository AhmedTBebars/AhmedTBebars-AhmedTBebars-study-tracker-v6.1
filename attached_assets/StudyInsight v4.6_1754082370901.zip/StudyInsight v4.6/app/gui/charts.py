"""
Charts and visualization components for Study Tracker
"""

import sys
from datetime import datetime, timedelta
from typing import List, Tuple

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QMainWindow, QScrollArea, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QPainter, QPen, QBrush, QColor

from ..core.database import DatabaseManager


class SimpleChartWidget(QWidget):
    """Simple chart widget using QPainter"""
    
    def __init__(self, title: str, data: List[Tuple], chart_type: str = "line"):
        super().__init__()
        self.title = title
        self.data = data
        self.chart_type = chart_type
        self.setMinimumSize(600, 400)
    
    def paintEvent(self, event):
        """Paint the chart"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Clear background
        painter.fillRect(self.rect(), QColor(255, 255, 255))
        
        # Draw title
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        painter.setFont(title_font)
        painter.setPen(QPen(QColor(0, 0, 0)))
        painter.drawText(20, 30, self.title)
        
        if not self.data:
            painter.drawText(20, 200, "No data available")
            return
        
        # Chart area
        margin = 50
        chart_width = self.width() - 2 * margin
        chart_height = self.height() - 2 * margin - 40  # Account for title
        chart_x = margin
        chart_y = 50  # Below title
        
        # Draw axes
        painter.setPen(QPen(QColor(0, 0, 0), 2))
        painter.drawLine(chart_x, chart_y + chart_height, chart_x + chart_width, chart_y + chart_height)  # X-axis
        painter.drawLine(chart_x, chart_y, chart_x, chart_y + chart_height)  # Y-axis
        
        if self.chart_type == "line":
            self.draw_line_chart(painter, chart_x, chart_y, chart_width, chart_height)
        elif self.chart_type == "bar":
            self.draw_bar_chart(painter, chart_x, chart_y, chart_width, chart_height)
    
    def draw_line_chart(self, painter, chart_x, chart_y, chart_width, chart_height):
        """Draw a line chart"""
        if len(self.data) < 2:
            return
        
        # Find max value for scaling
        max_val = max(max(point[1], point[2]) if len(point) > 2 else point[1] for point in self.data)
        if max_val == 0:
            max_val = 1
        
        # Draw data points and lines
        points = []
        for i, point in enumerate(self.data):
            x = chart_x + (i * chart_width) // (len(self.data) - 1)
            y1 = chart_y + chart_height - (point[1] * chart_height) // max_val
            
            # Draw point
            painter.setPen(QPen(QColor(255, 0, 0), 4))
            painter.drawPoint(x, y1)
            points.append((x, y1))
            
            # Draw second line if comparison data exists
            if len(point) > 2:
                y2 = chart_y + chart_height - (point[2] * chart_height) // max_val
                painter.setPen(QPen(QColor(0, 0, 255), 4))
                painter.drawPoint(x, y2)
        
        # Connect points with lines
        painter.setPen(QPen(QColor(255, 0, 0), 2))
        for i in range(len(points) - 1):
            painter.drawLine(points[i][0], points[i][1], points[i+1][0], points[i+1][1])
    
    def draw_bar_chart(self, painter, chart_x, chart_y, chart_width, chart_height):
        """Draw a bar chart"""
        if not self.data:
            return
        
        # Find max value for scaling
        max_val = max(point[1] for point in self.data)
        if max_val == 0:
            max_val = 1
        
        # Draw bars
        bar_width = chart_width // len(self.data) - 10
        for i, point in enumerate(self.data):
            x = chart_x + i * (chart_width // len(self.data)) + 5
            bar_height = (point[1] * chart_height) // max_val
            y = chart_y + chart_height - bar_height
            
            # Draw bar
            painter.setBrush(QBrush(QColor(100, 150, 255)))
            painter.setPen(QPen(QColor(0, 0, 0), 1))
            painter.drawRect(x, y, bar_width, bar_height)
            
            # Draw label
            label_font = QFont()
            label_font.setPointSize(8)
            painter.setFont(label_font)
            painter.drawText(x, chart_y + chart_height + 15, str(point[0])[:10])


class ChartWindow(QMainWindow):
    """Window for displaying charts"""
    
    def __init__(self, db_manager: DatabaseManager, chart_type: str, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.chart_type = chart_type
        
        self.setWindowTitle(f"Study Tracker - {chart_type.replace('_', ' ').title()}")
        self.setGeometry(200, 200, 800, 600)
        
        self.init_ui()
        self.load_chart_data()
    
    def init_ui(self):
        """Initialize chart window UI"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        # Period selection for comparisons
        if "comparison" in self.chart_type:
            period_label = QLabel("Period:")
            self.period_combo = QComboBox()
            self.period_combo.addItems(["Last 2 Weeks", "Last 2 Months", "Last 2 Quarters"])
            self.period_combo.currentTextChanged.connect(self.load_chart_data)
            
            controls_layout.addWidget(period_label)
            controls_layout.addWidget(self.period_combo)
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.load_chart_data)
        
        controls_layout.addWidget(refresh_btn)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Chart area
        self.chart_scroll = QScrollArea()
        self.chart_scroll.setWidgetResizable(True)
        
        self.chart_widget = None
        
        layout.addWidget(self.chart_scroll)
    
    def load_chart_data(self):
        """Load and display chart data"""
        try:
            if self.chart_type == "daily_progress":
                self.load_daily_progress()
            elif self.chart_type == "weekly_comparison":
                self.load_weekly_comparison()
            elif self.chart_type == "monthly_comparison":
                self.load_monthly_comparison()
        except Exception as e:
            # Create error chart
            self.chart_widget = SimpleChartWidget(f"Error loading {self.chart_type}", [])
            self.chart_scroll.setWidget(self.chart_widget)
    
    def load_daily_progress(self):
        """Load daily progress chart"""
        # Get last 30 days
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        
        daily_data = self.db_manager.get_daily_progress(
            start_date.strftime("%Y-%m-%d"),
            end_date.strftime("%Y-%m-%d")
        )
        
        # Convert to chart data (date, completion_rate)
        chart_data = []
        for date, total, completed in daily_data:
            completion_rate = (completed / total * 100) if total > 0 else 0
            chart_data.append((date, int(completion_rate)))
        
        self.chart_widget = SimpleChartWidget(
            "Daily Progress (Last 30 Days)",
            chart_data,
            "line"
        )
        self.chart_scroll.setWidget(self.chart_widget)
    
    def load_weekly_comparison(self):
        """Load weekly comparison chart"""
        today = datetime.now()
        
        # This week
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=6)
        
        # Last week
        last_week_start = week_start - timedelta(days=7)
        last_week_end = last_week_start + timedelta(days=6)
        
        # Get data for both weeks
        this_week_data = self.db_manager.get_daily_progress(
            week_start.strftime("%Y-%m-%d"),
            week_end.strftime("%Y-%m-%d")
        )
        
        last_week_data = self.db_manager.get_daily_progress(
            last_week_start.strftime("%Y-%m-%d"),
            last_week_end.strftime("%Y-%m-%d")
        )
        
        # Convert to chart data
        chart_data = []
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        
        for i in range(7):
            this_week_rate = 0
            last_week_rate = 0
            
            if i < len(this_week_data):
                total, completed = this_week_data[i][1], this_week_data[i][2]
                this_week_rate = (completed / total * 100) if total > 0 else 0
            
            if i < len(last_week_data):
                total, completed = last_week_data[i][1], last_week_data[i][2]
                last_week_rate = (completed / total * 100) if total > 0 else 0
            
            chart_data.append((days[i], int(this_week_rate), int(last_week_rate)))
        
        self.chart_widget = SimpleChartWidget(
            "Weekly Comparison (This Week vs Last Week)",
            chart_data,
            "line"
        )
        self.chart_scroll.setWidget(self.chart_widget)
    
    def load_monthly_comparison(self):
        """Load monthly comparison chart"""
        today = datetime.now()
        
        # This month
        month_start = today.replace(day=1)
        if today.month == 12:
            next_month = today.replace(year=today.year + 1, month=1, day=1)
        else:
            next_month = today.replace(month=today.month + 1, day=1)
        month_end = next_month - timedelta(days=1)
        
        # Last month
        if month_start.month == 1:
            last_month_start = month_start.replace(year=month_start.year - 1, month=12, day=1)
        else:
            last_month_start = month_start.replace(month=month_start.month - 1, day=1)
        last_month_end = month_start - timedelta(days=1)
        
        # Get stats for both months
        this_month_total, this_month_completed, _ = self.db_manager.get_completion_stats(
            month_start.strftime("%Y-%m-%d"),
            month_end.strftime("%Y-%m-%d")
        )
        
        last_month_total, last_month_completed, _ = self.db_manager.get_completion_stats(
            last_month_start.strftime("%Y-%m-%d"),
            last_month_end.strftime("%Y-%m-%d")
        )
        
        # Calculate rates
        this_month_rate = (this_month_completed / this_month_total * 100) if this_month_total > 0 else 0
        last_month_rate = (last_month_completed / last_month_total * 100) if last_month_total > 0 else 0
        
        chart_data = [
            ("This Month", int(this_month_rate)),
            ("Last Month", int(last_month_rate))
        ]
        
        self.chart_widget = SimpleChartWidget(
            "Monthly Comparison",
            chart_data,
            "bar"
        )
        self.chart_scroll.setWidget(self.chart_widget)
