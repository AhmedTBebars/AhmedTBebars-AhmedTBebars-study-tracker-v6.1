"""
Features module for Study Tracker
Contains notifications and scheduling functionality
"""

from .notifications import NotificationManager
from .scheduler import TaskScheduler

__all__ = ['NotificationManager', 'TaskScheduler']
