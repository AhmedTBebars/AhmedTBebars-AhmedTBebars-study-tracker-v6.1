"""
Task scheduling and background services for Study Tracker
"""

import threading
import time
from datetime import datetime, timedelta
from typing import List

from ..core.database import DatabaseManager
from ..core.models import Task
from .notifications import NotificationManager


class TaskScheduler:
    """Handles task scheduling and background operations"""
    
    def __init__(self, db_manager: DatabaseManager, notification_manager: NotificationManager):
        self.db_manager = db_manager
        self.notification_manager = notification_manager
        self.is_running = False
        self.scheduler_thread = None
        
        # Notification intervals (in seconds)
        self.overdue_check_interval = 3600  # 1 hour
        self.daily_reminder_interval = 21600  # 6 hours
        
        self.last_overdue_check = datetime.now()
        self.last_daily_reminder = datetime.now()
    
    def start(self):
        """Start the scheduler in background thread"""
        if self.is_running:
            return
        
        self.is_running = True
        self.scheduler_thread = threading.Thread(target=self._run_scheduler, daemon=True)
        self.scheduler_thread.start()
    
    def stop(self):
        """Stop the scheduler"""
        self.is_running = False
        if self.scheduler_thread and self.scheduler_thread.is_alive():
            self.scheduler_thread.join(timeout=5)
    
    def _run_scheduler(self):
        """Main scheduler loop"""
        while self.is_running:
            try:
                current_time = datetime.now()
                
                # Check for overdue tasks
                if (current_time - self.last_overdue_check).seconds >= self.overdue_check_interval:
                    self._check_overdue_tasks()
                    self.last_overdue_check = current_time
                
                # Send daily reminders
                if (current_time - self.last_daily_reminder).seconds >= self.daily_reminder_interval:
                    self._send_daily_reminder()
                    self.last_daily_reminder = current_time
                
                # Check for upcoming deadlines
                self._check_upcoming_deadlines()
                
                # Sleep for 60 seconds before next check
                time.sleep(60)
                
            except Exception as e:
                print(f"Scheduler error: {e}")
                time.sleep(300)  # Wait 5 minutes on error
    
    def _check_overdue_tasks(self):
        """Check for overdue tasks and send notifications"""
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            
            # Get all overdue tasks
            all_tasks = self.db_manager.get_tasks_date_range("2020-01-01", today)
            overdue_tasks = [task for task in all_tasks if task.is_overdue]
            
            if overdue_tasks:
                self.notification_manager.notify_overdue_tasks(len(overdue_tasks))
                
                # Send specific notifications for tasks overdue > 7 days
                warning_tasks = [task for task in overdue_tasks if task.needs_warning]
                for task in warning_tasks[:3]:  # Limit to 3 notifications
                    self.notification_manager.show_notification(
                        "Urgent: Long Overdue Task",
                        f"Task '{task.title}' has been overdue for {task.days_overdue} days!"
                    )
        
        except Exception as e:
            print(f"Error checking overdue tasks: {e}")
    
    def _send_daily_reminder(self):
        """Send daily study reminder"""
        try:
            current_hour = datetime.now().hour
            
            # Send reminders during study hours
            if 8 <= current_hour <= 22:  # 8 AM to 10 PM
                self.notification_manager.notify_daily_reminder()
        
        except Exception as e:
            print(f"Error sending daily reminder: {e}")
    
    def _check_upcoming_deadlines(self):
        """Check for upcoming task deadlines"""
        try:
            today = datetime.now()
            tomorrow = today + timedelta(days=1)
            next_week = today + timedelta(days=7)
            
            # Get tasks for next week
            upcoming_tasks = self.db_manager.get_tasks_date_range(
                tomorrow.strftime("%Y-%m-%d"),
                next_week.strftime("%Y-%m-%d")
            )
            
            for task in upcoming_tasks:
                if not task.is_done:
                    task_date = datetime.strptime(task.date, "%Y-%m-%d")
                    days_remaining = (task_date - today).days
                    
                    # Notify for tasks due in 1, 3, or 7 days
                    if days_remaining in [1, 3, 7]:
                        self.notification_manager.notify_task_deadline(
                            task.title, 
                            days_remaining
                        )
        
        except Exception as e:
            print(f"Error checking upcoming deadlines: {e}")
    
    def schedule_backup(self):
        """Schedule automatic database backup"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"data/backups/auto_backup_{timestamp}.db"
            
            # Ensure backup directory exists
            import os
            os.makedirs("data/backups", exist_ok=True)
            
            self.db_manager.backup_database(backup_path)
            self.notification_manager.notify_backup_created(backup_path)
        
        except Exception as e:
            print(f"Error creating automatic backup: {e}")
    
    def get_scheduler_status(self) -> dict:
        """Get current scheduler status"""
        return {
            'is_running': self.is_running,
            'last_overdue_check': self.last_overdue_check.isoformat(),
            'last_daily_reminder': self.last_daily_reminder.isoformat(),
            'thread_alive': self.scheduler_thread.is_alive() if self.scheduler_thread else False
        }


class TaskReminder:
    """Individual task reminder manager"""
    
    def __init__(self, task: Task, notification_manager: NotificationManager):
        self.task = task
        self.notification_manager = notification_manager
        self.reminder_sent = False
    
    def check_and_notify(self):
        """Check if reminder should be sent and send it"""
        if self.reminder_sent or self.task.is_done:
            return
        
        today = datetime.now().date()
        task_date = datetime.strptime(self.task.date, "%Y-%m-%d").date()
        
        # Send reminder if task is due today or overdue
        if task_date <= today:
            days_overdue = (today - task_date).days
            
            if days_overdue == 0:
                message = f"Task '{self.task.title}' is due today!"
            else:
                message = f"Task '{self.task.title}' is {days_overdue} day{'s' if days_overdue != 1 else ''} overdue!"
            
            self.notification_manager.show_notification("Task Reminder", message)
            self.reminder_sent = True
