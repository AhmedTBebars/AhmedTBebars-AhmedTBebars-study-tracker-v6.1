"""
Notification management for Study Tracker
Handles system notifications and reminders
"""

import os
import sys
from datetime import datetime
from typing import Optional

try:
    from plyer import notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False


class NotificationManager:
    """Manages system notifications"""
    
    def __init__(self):
        self.app_name = "Study Tracker"
        self.icon_path = self._get_icon_path()
    
    def _get_icon_path(self) -> Optional[str]:
        """Get path to application icon"""
        possible_paths = [
            "assets/icon.ico",
            "assets/icon.png",
            "assets/icon.svg"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return os.path.abspath(path)
        
        return None
    
    def show_notification(self, title: str, message: str, timeout: int = 10):
        """Show system notification"""
        try:
            if PLYER_AVAILABLE:
                notification.notify(
                    title=title,
                    message=message,
                    app_name=self.app_name,
                    app_icon=self.icon_path,
                    timeout=timeout
                )
            else:
                # Fallback: print to console
                print(f"[{self.app_name}] {title}: {message}")
        except Exception as e:
            print(f"Failed to show notification: {e}")
    
    def notify_overdue_tasks(self, count: int):
        """Notify about overdue tasks"""
        if count == 0:
            return
        
        title = "Overdue Tasks"
        message = f"You have {count} overdue task{'s' if count != 1 else ''} that need attention."
        
        self.show_notification(title, message)
    
    def notify_daily_reminder(self):
        """Send daily study reminder"""
        title = "Daily Study Reminder"
        message = "Don't forget to log your study progress for today!"
        
        self.show_notification(title, message)
    
    def notify_task_deadline(self, task_title: str, days_remaining: int):
        """Notify about approaching task deadline"""
        title = "Task Deadline Approaching"
        
        if days_remaining == 0:
            message = f"Task '{task_title}' is due today!"
        elif days_remaining == 1:
            message = f"Task '{task_title}' is due tomorrow!"
        else:
            message = f"Task '{task_title}' is due in {days_remaining} days."
        
        self.show_notification(title, message)
    
    def notify_progress_logged(self, task_count: int):
        """Notify that progress has been logged"""
        title = "Progress Logged"
        message = f"Successfully logged progress for {task_count} task{'s' if task_count != 1 else ''}."
        
        self.show_notification(title, message, timeout=5)
    
    def notify_backup_created(self, backup_path: str):
        """Notify that backup has been created"""
        title = "Backup Created"
        message = f"Database backup saved to {backup_path}"
        
        self.show_notification(title, message, timeout=5)
    
    def notify_app_minimized(self):
        """Notify that app has been minimized to system tray"""
        title = self.app_name
        message = "Application minimized to system tray. Notifications will continue in the background."
        
        self.show_notification(title, message, timeout=3)


class BackgroundNotificationService:
    """Background service for sending periodic notifications"""
    
    def __init__(self, notification_manager: NotificationManager):
        self.notification_manager = notification_manager
        self.is_running = False
    
    def start(self):
        """Start background notification service"""
        self.is_running = True
        # In a real implementation, this would run in a separate thread
        # For now, we'll handle notifications through the scheduler
    
    def stop(self):
        """Stop background notification service"""
        self.is_running = False
    
    def send_periodic_reminders(self):
        """Send periodic study reminders"""
        if not self.is_running:
            return
        
        current_hour = datetime.now().hour
        
        # Send reminders at specific times
        if current_hour in [9, 14, 19]:  # 9 AM, 2 PM, 7 PM
            self.notification_manager.notify_daily_reminder()
