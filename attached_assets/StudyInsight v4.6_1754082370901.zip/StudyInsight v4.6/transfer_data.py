#!/usr/bin/env python3
"""
SQLite Database Migration Script for Study Tracker

This script transfers data from an old SQLite database to the new Study Tracker database,
ensuring schema compatibility and avoiding duplicates.

Usage: python transfer_data.py
"""

import sqlite3
import os
import sys
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any

# Database paths
OLD_DB_PATH = "attached_assets/study_1753986375672.db"
NEW_DB_PATH = "data/study_tracker.db"

# Default values for missing columns
DEFAULT_VALUES = {
    'order_index': 0,
    'progress': 0,
    'difficulty': 'medium',
    'is_done': 0
}

# Required columns in the new database
REQUIRED_COLUMNS = [
    'id', 'date', 'title', 'topic', 'is_done', 
    'progress', 'difficulty', 'order_index', 
    'created_at', 'updated_at'
]

def check_database_exists(db_path: str) -> bool:
    """Check if database file exists and is accessible"""
    if not os.path.exists(db_path):
        return False
    
    try:
        # Try to connect and verify it's a valid SQLite database
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            return True
    except sqlite3.Error:
        return False

def get_table_columns(db_path: str, table_name: str) -> List[str]:
    """Get list of columns in a table"""
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [row[1] for row in cursor.fetchall()]
            return columns
    except sqlite3.Error:
        return []

def get_old_tasks(db_path: str) -> List[Dict[str, Any]]:
    """Read all tasks from the old database"""
    tasks = []
    
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row  # Enable column access by name
            cursor = conn.cursor()
            
            # Check if tasks table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks';")
            if not cursor.fetchone():
                print("Warning: 'tasks' table not found in old database")
                return tasks
            
            # Get all columns in the old tasks table
            old_columns = get_table_columns(db_path, 'tasks')
            print(f"Old database columns: {old_columns}")
            
            # Read all rows
            cursor.execute("SELECT * FROM tasks")
            rows = cursor.fetchall()
            
            for row in rows:
                task = {}
                # Convert row to dictionary, handling missing columns
                for col in old_columns:
                    task[col] = row[col]
                
                # Ensure required fields exist with defaults
                if 'date' not in task or not task['date']:
                    print(f"Warning: Skipping row with missing date: {dict(row)}")
                    continue
                
                if 'title' not in task or not task['title']:
                    print(f"Warning: Skipping row with missing title: {dict(row)}")
                    continue
                
                # Set default values for missing or None columns
                task.setdefault('topic', 'General')
                if task.get('topic') is None:
                    task['topic'] = 'General'
                
                task.setdefault('is_done', DEFAULT_VALUES['is_done'])
                if task.get('is_done') is None:
                    task['is_done'] = DEFAULT_VALUES['is_done']
                
                task.setdefault('progress', DEFAULT_VALUES['progress'])
                if task.get('progress') is None:
                    task['progress'] = DEFAULT_VALUES['progress']
                
                task.setdefault('difficulty', DEFAULT_VALUES['difficulty'])
                if task.get('difficulty') is None or task.get('difficulty') == '':
                    task['difficulty'] = DEFAULT_VALUES['difficulty']
                
                task.setdefault('order_index', DEFAULT_VALUES['order_index'])
                if task.get('order_index') is None:
                    task['order_index'] = DEFAULT_VALUES['order_index']
                
                tasks.append(task)
            
            print(f"Successfully read {len(tasks)} tasks from old database")
            
    except sqlite3.Error as e:
        print(f"Error reading from old database: {e}")
        raise
    
    return tasks

def ensure_new_database_schema(db_path: str) -> None:
    """Ensure the new database has the correct schema"""
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Create tasks table with full schema if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    title TEXT NOT NULL,
                    topic TEXT NOT NULL,
                    is_done INTEGER DEFAULT 0,
                    progress INTEGER DEFAULT 0,
                    difficulty TEXT DEFAULT 'medium',
                    order_index INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_date ON tasks(date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_topic ON tasks(topic)")
            
            conn.commit()
            print("New database schema verified/created successfully")
            
    except sqlite3.Error as e:
        print(f"Error setting up new database schema: {e}")
        raise

def check_duplicate_exists(conn: sqlite3.Connection, date: str, title: str) -> bool:
    """Check if a task with the same date and title already exists"""
    cursor = conn.cursor()
    cursor.execute(
        "SELECT COUNT(*) FROM tasks WHERE date = ? AND title = ?", 
        (date, title)
    )
    count = cursor.fetchone()[0]
    return count > 0

def insert_tasks_to_new_database(db_path: str, tasks: List[Dict[str, Any]]) -> Tuple[int, int]:
    """Insert tasks into the new database, avoiding duplicates"""
    inserted_count = 0
    duplicate_count = 0
    
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            for task in tasks:
                # Check for duplicates
                if check_duplicate_exists(conn, task['date'], task['title']):
                    duplicate_count += 1
                    print(f"Skipping duplicate: '{task['title']}' on {task['date']}")
                    continue
                
                # Get the next order_index for this date
                cursor.execute(
                    "SELECT COALESCE(MAX(order_index), -1) FROM tasks WHERE date = ?",
                    (task['date'],)
                )
                max_order = cursor.fetchone()[0]
                task['order_index'] = max_order + 1
                
                # Convert values safely to appropriate types
                try:
                    is_done = int(task['is_done']) if task['is_done'] is not None else 0
                    progress = int(task['progress']) if task['progress'] is not None else 0
                    order_index = int(task['order_index']) if task['order_index'] is not None else 0
                    difficulty = str(task['difficulty']) if task['difficulty'] is not None else 'medium'
                except (ValueError, TypeError) as e:
                    print(f"Warning: Data conversion error for task '{task.get('title', 'Unknown')}': {e}")
                    # Use defaults for problematic values
                    is_done = 0
                    progress = 0
                    order_index = 0
                    difficulty = 'medium'
                
                # Insert the task
                cursor.execute("""
                    INSERT INTO tasks (date, title, topic, is_done, progress, difficulty, order_index)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    task['date'],
                    task['title'],
                    task['topic'],
                    is_done,
                    progress,
                    difficulty,
                    order_index
                ))
                
                inserted_count += 1
                print(f"Inserted: '{task['title']}' ({task['topic']}) on {task['date']}")
            
            conn.commit()
            
    except sqlite3.Error as e:
        print(f"Error inserting tasks into new database: {e}")
        raise
    
    return inserted_count, duplicate_count

def verify_transfer(db_path: str) -> Dict[str, int]:
    """Verify the transfer by counting tasks in the new database"""
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM tasks")
            total_tasks = cursor.fetchone()[0]
            
            # Completed tasks
            cursor.execute("SELECT COUNT(*) FROM tasks WHERE is_done = 1")
            completed_tasks = cursor.fetchone()[0]
            
            # Tasks by difficulty
            cursor.execute("SELECT difficulty, COUNT(*) FROM tasks GROUP BY difficulty")
            difficulty_counts = dict(cursor.fetchall())
            
            return {
                'total': total_tasks,
                'completed': completed_tasks,
                'difficulty_counts': difficulty_counts
            }
            
    except sqlite3.Error as e:
        print(f"Error verifying transfer: {e}")
        return {}

def main():
    """Main transfer function"""
    print("=" * 60)
    print("SQLite Database Migration Script for Study Tracker")
    print("=" * 60)
    
    try:
        # Step 1: Check if both databases exist
        print("\n1. Checking database files...")
        
        if not check_database_exists(OLD_DB_PATH):
            raise FileNotFoundError(
                f"Old database not found or invalid: {OLD_DB_PATH}\n"
                f"Please ensure the file exists and is a valid SQLite database."
            )
        print(f"✓ Old database found: {OLD_DB_PATH}")
        
        # The new database will be created if it doesn't exist
        print(f"✓ New database path: {NEW_DB_PATH}")
        
        # Step 2: Ensure new database schema
        print("\n2. Setting up new database schema...")
        ensure_new_database_schema(NEW_DB_PATH)
        
        # Step 3: Read tasks from old database
        print("\n3. Reading tasks from old database...")
        old_tasks = get_old_tasks(OLD_DB_PATH)
        
        if not old_tasks:
            print("No tasks found in old database. Nothing to transfer.")
            return
        
        # Step 4: Insert tasks into new database
        print(f"\n4. Transferring {len(old_tasks)} tasks to new database...")
        inserted_count, duplicate_count = insert_tasks_to_new_database(NEW_DB_PATH, old_tasks)
        
        # Step 5: Verify transfer
        print("\n5. Verifying transfer...")
        verification = verify_transfer(NEW_DB_PATH)
        
        # Step 6: Print summary
        print("\n" + "=" * 60)
        print("TRANSFER SUMMARY")
        print("=" * 60)
        print(f"Tasks found in old database: {len(old_tasks)}")
        print(f"Tasks successfully inserted: {inserted_count}")
        print(f"Duplicate tasks skipped: {duplicate_count}")
        print(f"Total tasks in new database: {verification.get('total', 'Unknown')}")
        print(f"Completed tasks: {verification.get('completed', 'Unknown')}")
        
        if 'difficulty_counts' in verification:
            print("\nTasks by difficulty:")
            for difficulty, count in verification['difficulty_counts'].items():
                print(f"  {difficulty}: {count}")
        
        print(f"\n✓ Database migration completed successfully!")
        print(f"✓ New database is ready at: {NEW_DB_PATH}")
        
        if inserted_count > 0:
            print(f"✓ You can now use your Study Tracker application with the migrated data.")
        
    except FileNotFoundError as e:
        print(f"\n❌ File Error: {e}")
        sys.exit(1)
    
    except sqlite3.Error as e:
        print(f"\n❌ Database Error: {e}")
        sys.exit(1)
    
    except Exception as e:
        print(f"\n❌ Unexpected Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()