# Study Tracker - Desktop Application

## Overview

Study Tracker is a comprehensive desktop study management application built with Python and PySide6. It provides smart task management, progress tracking, reporting capabilities, and background notifications, all backed by a local SQLite database.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### CSV Import Feature (July 31, 2025)
- Added comprehensive CSV import functionality to GUI
- Menu location: Settings → Import CSV (📄 Import CSV)  
- Supports Date,Title,Topic,Is_Done format with automatic defaults
- Smart duplicate detection based on Date + Title combination
- Robust error handling with user-friendly feedback
- Successfully tested with 10 tasks imported and duplicate prevention verified

## System Architecture

### Frontend Architecture
- **GUI Framework**: PySide6 (Qt6 for Python) providing native desktop interface
- **Architecture Pattern**: Model-View-Controller (MVC) with separation of concerns
- **Main Components**:
  - MainWindow: Central application interface
  - Custom Widgets: Reusable UI components for tasks and lists
  - Dialogs: Modal windows for user interactions
  - Charts: Visual data representation using QPainter

### Backend Architecture
- **Database Layer**: SQLite for local data persistence
- **Core Models**: Task entities with status tracking and difficulty levels
- **Service Layer**: Database management, notifications, and task scheduling
- **Background Services**: Threaded scheduler for notifications and reminders

### Application Structure
```
StudyTracker/
├── app/
│   ├── core/          # Database and models
│   ├── gui/           # User interface components
│   └── features/      # Background services
├── data/              # SQLite database and backups
├── assets/            # Icons and resources
├── config.py          # Application configuration
└── main.py           # Application entry point
```

## Key Components

### Database Management (SQLite)
- **Purpose**: Local data persistence without external dependencies
- **Schema**: Tasks table with indexing for performance
- **Features**: Automatic backup system, migration support
- **Location**: `data/study_tracker.db`

### Task Management System
- **Smart Filtering**: Shows only relevant overdue tasks (related to today's topics)
- **Manual Ordering**: Drag-and-drop reordering with database persistence
- **Task Operations**: CRUD operations with real-time UI updates
- **Status Tracking**: Visual indicators for completion, progress, and overdue states

### Progress Logging Workflow
- **Intelligent Sequencing**: Processes today's tasks first, then related overdue tasks
- **Conditional Logic**: 
  - "No" response → Mark incomplete immediately
  - "Yes" response → Collect progress percentage and difficulty level
- **Real-time Updates**: Database persistence after each user response

### Notification System
- **Background Service**: Continues running when GUI is minimized
- **Native Integration**: OS-level notifications with app branding
- **Smart Reminders**: Overdue alerts, daily study reminders, deadline notifications
- **Fallback Support**: Graceful degradation if notification libraries unavailable

### Reporting and Visualization
- **Multiple Report Types**: Daily, weekly, monthly, and comprehensive reports
- **Custom Charts**: QPainter-based visualization for performance
- **Comparative Analysis**: Week-to-week and month-to-month comparisons
- **Calendar Integration**: Historical task viewing and report generation

## Data Flow

1. **Task Creation**: User input → Validation → Database storage → UI refresh
2. **Progress Logging**: Guided workflow → Conditional questions → Real-time database updates
3. **Task Reordering**: Drag-and-drop → Order index calculation → Database persistence
4. **Report Generation**: Date selection → Database queries → Chart rendering
5. **Background Notifications**: Scheduler thread → Task evaluation → System notifications

## External Dependencies

### Core Dependencies
- **PySide6**: GUI framework for cross-platform desktop interface
- **SQLite3**: Built-in Python database (no external database required)
- **Plyer**: Cross-platform notification system (optional with fallback)

### Python Standard Library Usage
- **threading**: Background scheduler service
- **datetime**: Date/time operations and calculations
- **pathlib**: Cross-platform file path handling
- **sqlite3**: Database operations
- **os/sys**: System integration and path management

### Optional Dependencies
- Chart libraries could be added later for enhanced visualization
- Database migration tools for schema updates
- Backup/export functionality for data portability

## Deployment Strategy

### Desktop Application Deployment
- **Target Platforms**: Windows, macOS, Linux (PySide6 cross-platform support)
- **Packaging Options**: 
  - PyInstaller for standalone executables
  - cx_Freeze for cross-platform distribution
  - Native packaging for each OS
- **Data Persistence**: Local SQLite database in user data directory
- **Configuration**: File-based configuration with sensible defaults

### Development Setup
- **Requirements**: Python 3.8+, PySide6, optional Plyer
- **Database**: Auto-initialization on first run
- **Assets**: SVG icons for scalability across different screen densities
- **Directory Structure**: Automatic creation of required data directories

### Background Service Integration
- **System Tray**: Minimize to tray functionality for persistent operation
- **Auto-start**: Optional system startup integration
- **Resource Management**: Efficient threading for background operations
- **Graceful Shutdown**: Proper cleanup of database connections and threads

### Backup and Recovery
- **Automatic Backups**: Scheduled database backups with retention policy
- **Data Recovery**: Restore functionality from backup files
- **Export/Import**: Task data portability between installations
- **Migration Support**: Database schema versioning for updates