#!/usr/bin/env python3
"""
Study Tracker - Desktop Study Management Application

A comprehensive desktop study tracking application with PySide6 GUI,
featuring smart task management, progress logging, background notifications,
and local SQLite storage.

Author: Study Tracker Team
Version: 1.0.0
License: MIT
"""

import sys
import os
import signal
from pathlib import Path

# Add the app directory to the Python path
app_dir = Path(__file__).parent
sys.path.insert(0, str(app_dir))

from PySide6.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QMessageBox
from PySide6.QtCore import QTimer, QObject, QThread, Signal
from PySide6.QtGui import QIcon, QAction

from app.gui.main_window import MainWindow
from app.core.database import DatabaseManager
from app.features.notifications import NotificationManager
from app.features.scheduler import TaskScheduler
import config


class StudyTrackerApp(QApplication):
    """Main application class"""
    
    def __init__(self, argv):
        super().__init__(argv)
        
        # Set application properties
        self.setApplicationName(config.APP_NAME)
        self.setApplicationVersion(config.APP_VERSION)
        self.setOrganizationName("Study Tracker Team")
        
        # Ensure required directories exist
        config.ensure_directories()
        
        # Initialize components
        self.db_manager = None
        self.notification_manager = None
        self.scheduler = None
        self.main_window = None
        self.system_tray = None
        
        # Setup application
        self.setup_database()
        self.setup_notifications()
        self.setup_system_tray()
        self.setup_main_window()
        self.setup_scheduler()
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        # Timer to process events during background operation
        self.event_timer = QTimer()
        self.event_timer.timeout.connect(self.processEvents)
        self.event_timer.start(100)  # Process events every 100ms
    
    def setup_database(self):
        """Initialize database manager"""
        try:
            self.db_manager = DatabaseManager()
            print("Database initialized successfully")
        except Exception as e:
            self.show_error("Database Error", f"Failed to initialize database: {str(e)}")
            sys.exit(1)
    
    def setup_notifications(self):
        """Initialize notification manager"""
        try:
            self.notification_manager = NotificationManager()
            print("Notification manager initialized")
        except Exception as e:
            print(f"Warning: Notification manager initialization failed: {e}")
            # Continue without notifications
            self.notification_manager = NotificationManager()  # Use fallback
    
    def setup_system_tray(self):
        """Setup system tray functionality"""
        if not QSystemTrayIcon.isSystemTrayAvailable():
            print("Warning: System tray not available")
            return
        
        try:
            # Create system tray icon
            self.system_tray = QSystemTrayIcon(self)
            
            # Set tray icon
            icon_path = "assets/icon.svg"
            if os.path.exists(icon_path):
                self.system_tray.setIcon(QIcon(icon_path))
            else:
                # Use default icon
                self.system_tray.setIcon(self.style().standardIcon(self.style().SP_ComputerIcon))
            
            # Create tray menu
            tray_menu = QMenu()
            
            # Show/Hide action
            show_action = QAction("Show Study Tracker", self)
            show_action.triggered.connect(self.show_main_window)
            tray_menu.addAction(show_action)
            
            tray_menu.addSeparator()
            
            # Quick actions
            add_task_action = QAction("➕ Add Task", self)
            add_task_action.triggered.connect(self.quick_add_task)
            tray_menu.addAction(add_task_action)
            
            log_progress_action = QAction("📝 Log Progress", self)
            log_progress_action.triggered.connect(self.quick_log_progress)
            tray_menu.addAction(log_progress_action)
            
            tray_menu.addSeparator()
            
            # Exit action
            exit_action = QAction("Exit", self)
            exit_action.triggered.connect(self.quit_application)
            tray_menu.addAction(exit_action)
            
            self.system_tray.setContextMenu(tray_menu)
            self.system_tray.setToolTip(f"{config.APP_NAME} - Running in background")
            
            # Handle tray icon activation
            self.system_tray.activated.connect(self.on_tray_activated)
            
            # Show tray icon
            self.system_tray.show()
            
            print("System tray initialized")
            
        except Exception as e:
            print(f"Warning: System tray setup failed: {e}")
    
    def setup_main_window(self):
        """Initialize main window"""
        try:
            self.main_window = MainWindow()
            
            # Override close event to minimize to tray instead of exit
            original_close_event = self.main_window.closeEvent
            def new_close_event(event):
                if self.system_tray and self.system_tray.isVisible():
                    self.main_window.hide()
                    self.notification_manager.notify_app_minimized()
                    event.ignore()
                else:
                    original_close_event(event)
            
            self.main_window.closeEvent = new_close_event
            
            print("Main window initialized")
            
        except Exception as e:
            self.show_error("Window Error", f"Failed to initialize main window: {str(e)}")
            sys.exit(1)
    
    def setup_scheduler(self):
        """Initialize task scheduler"""
        try:
            self.scheduler = TaskScheduler(self.db_manager, self.notification_manager)
            self.scheduler.start()
            print("Task scheduler started")
        except Exception as e:
            print(f"Warning: Task scheduler setup failed: {e}")
    
    def show_main_window(self):
        """Show and raise main window"""
        if self.main_window:
            self.main_window.show()
            self.main_window.raise_()
            self.main_window.activateWindow()
    
    def on_tray_activated(self, reason):
        """Handle system tray icon activation"""
        if reason == QSystemTrayIcon.DoubleClick:
            self.show_main_window()
    
    def quick_add_task(self):
        """Quick add task from system tray"""
        self.show_main_window()
        if self.main_window:
            self.main_window.add_task()
    
    def quick_log_progress(self):
        """Quick log progress from system tray"""
        self.show_main_window()
        if self.main_window:
            self.main_window.log_progress()
    
    def quit_application(self):
        """Quit application completely"""
        if self.scheduler:
            self.scheduler.stop()
        
        if self.system_tray:
            self.system_tray.hide()
        
        self.quit()
    
    def signal_handler(self, signum, frame):
        """Handle system signals for graceful shutdown"""
        print(f"\nReceived signal {signum}, shutting down gracefully...")
        self.quit_application()
    
    def show_error(self, title: str, message: str):
        """Show error message"""
        print(f"Error - {title}: {message}")
        if hasattr(self, 'main_window') and self.main_window:
            QMessageBox.critical(self.main_window, title, message)
        else:
            # Create temporary message box
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Critical)
            msg_box.setWindowTitle(title)
            msg_box.setText(message)
            msg_box.exec()


def main():
    """Main entry point"""
    # Create application
    app = StudyTrackerApp(sys.argv)
    
    # Show main window
    app.show_main_window()
    
    # Start event loop
    try:
        exit_code = app.exec()
        print("Application closed")
        return exit_code
    except KeyboardInterrupt:
        print("\nApplication interrupted by user")
        app.quit_application()
        return 0
    except Exception as e:
        print(f"Application error: {e}")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
