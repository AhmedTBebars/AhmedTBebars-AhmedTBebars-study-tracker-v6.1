"""
Configuration settings for Study Tracker
"""

import os
from pathlib import Path

# Application settings
APP_NAME = "Study Tracker"
APP_VERSION = "1.0.0"
APP_DESCRIPTION = "Desktop study tracking application with smart task management"

# Paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
BACKUP_DIR = DATA_DIR / "backups"
ASSETS_DIR = BASE_DIR / "assets"

# Database settings
DATABASE_PATH = DATA_DIR / "study_tracker.db"
BACKUP_RETENTION_DAYS = 30

# UI settings
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
MIN_WINDOW_WIDTH = 800
MIN_WINDOW_HEIGHT = 600

# Colors
COLORS = {
    'completed': '#e8f5e8',      # Light green
    'overdue': '#ffeaa7',        # Light orange/yellow
    'in_progress': '#e3f2fd',    # Light blue
    'pending': '#f9f9f9',        # Light gray
    'text_primary': '#000000',   # Black
    'text_secondary': '#666666', # Dark gray
    'text_muted': '#888888',     # Medium gray
}

# Icons
TASK_ICONS = {
    'completed': '✔️',
    'in_progress': '⏳',
    'overdue': '⚠️',
    'pending': '📝',
    'warning': '⚠️',
}

# Notification settings
NOTIFICATION_SETTINGS = {
    'enabled': True,
    'overdue_check_interval': 3600,    # 1 hour in seconds
    'daily_reminder_interval': 21600,  # 6 hours in seconds
    'notification_timeout': 10,        # seconds
    'max_notifications_per_batch': 3,
}

# Scheduler settings
SCHEDULER_SETTINGS = {
    'check_interval': 60,              # seconds
    'reminder_hours': [9, 14, 19],     # 9 AM, 2 PM, 7 PM
    'backup_interval_hours': 24,       # Daily backup
}

# Chart settings
CHART_SETTINGS = {
    'default_period_days': 30,
    'max_chart_points': 100,
    'chart_colors': {
        'primary': '#FF6B6B',
        'secondary': '#4ECDC4',
        'background': '#FFFFFF',
        'grid': '#E0E0E0',
    }
}

# Development settings
DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')

# Ensure directories exist
def ensure_directories():
    """Ensure all required directories exist"""
    DATA_DIR.mkdir(exist_ok=True)
    BACKUP_DIR.mkdir(exist_ok=True)
    ASSETS_DIR.mkdir(exist_ok=True)

# Application constants
MAX_TASK_TITLE_LENGTH = 200
MAX_TOPIC_LENGTH = 100
MIN_PROGRESS_PERCENTAGE = 0
MAX_PROGRESS_PERCENTAGE = 100

# Date formats
DATE_FORMAT = "%Y-%m-%d"
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
DISPLAY_DATE_FORMAT = "%B %d, %Y"
DISPLAY_DATETIME_FORMAT = "%B %d, %Y at %I:%M %p"

# Task priorities (if needed for future expansion)
TASK_PRIORITIES = {
    'low': 1,
    'medium': 2,
    'high': 3,
    'urgent': 4,
}

# Export configuration for easy import
__all__ = [
    'APP_NAME', 'APP_VERSION', 'APP_DESCRIPTION',
    'DATABASE_PATH', 'BACKUP_DIR', 'ASSETS_DIR',
    'COLORS', 'TASK_ICONS', 'NOTIFICATION_SETTINGS',
    'SCHEDULER_SETTINGS', 'CHART_SETTINGS',
    'ensure_directories'
]
